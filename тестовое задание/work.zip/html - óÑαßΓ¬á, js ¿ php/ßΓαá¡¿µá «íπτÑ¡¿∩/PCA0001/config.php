<?php

App::setConfig([
    'type' => 'resource',
    'page_title' => 'Animal Cards',
    'img_path' => '/resources/PCA0001/imgs/',
    'app_path' => '/resources/PCA0001/',
    'pinterest_description' => 'Animal Picture Card Resource - teach.starfall.com',
    'pinterest_image' => 'animal-cards-generator.jpg',
]);